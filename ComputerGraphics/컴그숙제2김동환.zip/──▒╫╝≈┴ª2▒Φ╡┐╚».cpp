

#include <gl/freeglut.h>
#include <random>
#include <time.h>
#include <math.h>

#define MAKECENTER 200
#define EXIST 1
#define XZ 0
#define XY 1
#define YZ 2
#define X 0
#define Z 2
#define Y 1
#define PI 3.1415f

int angle[2] = { 0 };

GLvoid drawScene(GLvoid);
GLvoid Reshape(int w, int h);
float Cube_Color[1600][4] = { 0.2, 0.2, 0.2, 1.0 };
float Snow_locate[40][40][3] = { 0, 0 ,0 };
int Tree_locate[10][3] = { 0 };
float rail_road[10][25][3] = { 0 };
float rail_angle[10][10][3] = { 0 };
float rail_position[10][25][3] = { 0 };
float position[10][25][3] = { 0 };

int s_location[3] = { 0 };
int s_location1[3] = { 150 };
int s_angle[3] = { 0 };
int leg_angle = 0;
bool leg_updown = false;


bool meet = false;
int s_dir = 0;
int s_dir1 = -1;
int dir = 0;
int blocked = 0;
int blocked1 = 0;
bool jump = false;
bool jump1 = false;
bool init = false;

bool robot_select = false;

int mx, my = 0; //���콺 ��ǥ�� ����
bool mdown = FALSE;
float timer = 100 / 6;
void TimerFunction(int value);
bool left_button;
bool right_button = false;
float point[10][3] = { 0 };

int cant = -1;
int start_available = 0;
bool go = false;

bool one_light = true;
bool two_light = true;
int light_angle_trigger = 0;

float anglee[3] = { 0 }; //ī�޶� ��������
float eye[3] = { 0 }; //ī�޶� ��ġ ����
int upp = 0; //ī�޶� Y���� Translate�� �ű��
int yard = 0; //ī�޶� X���� Traslate�� �ű��
int forward = 0; //ī�޶� Z���� Traslate�� �ű��
int star = 0; //��������, ī�޶� �� ��ȯ ����
int light_angle = 0;
bool normal_switch = false;
int current_amount = 0;
//ī�޶� �̵� �Լ���

void orientMey(float ang)
{
	eye[2] = eye[2] * cos(ang) - eye[0] * sin(ang);
	eye[0] = eye[2] * sin(ang) + eye[0] * cos(ang);
	eye[1] = eye[1];
}

void orientMex(float ang)
{
	//gluLookAt(0.0, 0.0, 0.0, 0.0, -sin(1 / 180.0 * PI), -cos(1 / 180.0 * PI), 0.0, 1.0, 0.0);
	eye[1] = eye[1] * cos(ang) - eye[2] * sin(ang);
	eye[2] = eye[1] * sin(ang) + eye[2] * cos(ang);
	eye[0] = eye[0];
}

void orientMez(float ang)
{
	eye[0] = eye[0] * cos(ang) - eye[1] * sin(ang);
	eye[1] = eye[0] * sin(ang) + eye[1] * cos(ang);
	eye[2] = eye[2];
}

void RotateX()
{
	glRotatef(10.0, 1.0, 0.0, 0.0);
}

void RotateY()
{
	glRotatef(10.0, 0.0, 1.0, 0.0);
}

void RotateZ()
{
	glRotatef(10.0, 0.0, 0.0, 1.0);
}

//ī�޶� �̵��Լ� ��

//���� �׸��� �Լ���
GLfloat rail_steel[] = { 0.6f, 0.6f, 0.6f, 1.0f };
GLfloat rail_wood[] = { 0.8f, 0.6f, 0.2f, 0.5f };
GLfloat specref_rail[] = { 0.2f, 0.2f, 0.2f, 0.2f };
GLfloat DiffuseLight[] = { 0.9f, 0.5f, 0.5f, 1.0f };
GLfloat DiffuseLight1[] = { 0.0f, 0.5f, 1.0f, 1.0f };
GLfloat specref[] = { 0.5f, 0.5f, 0.5f, 1.0f };
GLfloat ambientLight[] = { 0.2f, 0.2f, 0.2f, 1.0f };
GLfloat AmbientLight[] = { 0.2f, 0.2f, 0.2f ,1.0f };
GLfloat gray[] = { 0.2f, 0.2f, 0.2f, 1.0f };

void Lighting()
{
	GLfloat lightPos[] = { 170.0, 30.0, 20.0, 1.0 };
	GLfloat lightPos2[] = { -170.0, 30.0, -20.0, 1.0 };



	glEnable(GL_LIGHTING);

	glLightfv(GL_LIGHT0, GL_AMBIENT, AmbientLight);
	glLightfv(GL_LIGHT0, GL_DIFFUSE, DiffuseLight);
	glLightfv(GL_LIGHT0, GL_SPECULAR, specref);

	glLightfv(GL_LIGHT1, GL_AMBIENT, AmbientLight);
	glLightfv(GL_LIGHT1, GL_DIFFUSE, DiffuseLight1);
	//glLightfv(GL_LIGHT1, GL_SPECULAR, specref);


	glLightfv(GL_LIGHT0, GL_POSITION, lightPos);
	glLightfv(GL_LIGHT1, GL_POSITION, lightPos2);

	glPushMatrix();
	glTranslatef(180.0, 30.0, 20.0);
	glutSolidCube(20);
	glPopMatrix();
	glPushMatrix();
	glTranslatef(-180.0, 30.0, -20.0);
	glutSolidCube(20);
	glPopMatrix();
	//if (one_light != true)
	//	glDisable(GL_LIGHT0);
	if (two_light != true)
		glDisable(GL_LIGHT1);

	//if (one_light == true)
	//	glEnable(GL_LIGHT0);
	if (two_light == true)
		glEnable(GL_LIGHT1);

	glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, gray);
	glMaterialfv(GL_FRONT, GL_SPECULAR, specref);
	glMateriali(GL_FRONT, GL_SHININESS, 64);

	if (light_angle_trigger == 1)
		light_angle = (light_angle % 360) + 2;
	if (light_angle_trigger == 2)
		light_angle = (light_angle % 360) - 2;

}

GLfloat Red[] = { 0.8f, 0.2f, 0.2f, 1.0f };

void tunnel()
{
	glutSolidTorus(3, 30, 20, 20);
}

void Rail_column(float x, float y, float z)
{
	if (cant == -1)
	{
		glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, rail_wood);
		glMaterialfv(GL_FRONT, GL_SPECULAR, specref_rail);
		glMateriali(GL_FRONT, GL_SHININESS, 64);
	}
	else
	{
		glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, Red);
		glMaterialfv(GL_FRONT, GL_SPECULAR, specref_rail);
		glMateriali(GL_FRONT, GL_SHININESS, 64);
	}
	glBegin(GL_QUADS);
	{
		glVertex3f(x - 5, y, z - 5);
		glVertex3f(x + 5, y, z - 5);
		glVertex3f(x + 5, -50, z - 5);
		glVertex3f(x - 5, -50, z - 5);
	}
	glEnd();
	glBegin(GL_QUADS);
	{
		glVertex3f(x - 5, y, z + 5);
		glVertex3f(x + 5, y, z + 5);
		glVertex3f(x + 5, -50, z + 5);
		glVertex3f(x - 5, -50, z + 5);
	}
	glEnd();
	glBegin(GL_QUADS);
	{
		glVertex3f(x - 5, y, z - 5);
		glVertex3f(x - 5, y, z + 5);
		glVertex3f(x - 5, -50, z + 5);
		glVertex3f(x - 5, -50, z - 5);
	}
	glEnd();
	glBegin(GL_QUADS);
	{

		glVertex3f(x + 5, y, z - 5);
		glVertex3f(x + 5, y, z + 5);
		glVertex3f(x + 5, -50, z + 5);
		glVertex3f(x + 5, -50, z - 5);
	}
	glEnd();
}

void Rail_model()
{
	glPushMatrix();
	{
		glRotatef(90, 0, 0, 1);
		glPushMatrix();
		{
			if (cant == -1)
			{
				glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, rail_wood);
				glMaterialfv(GL_FRONT, GL_SPECULAR, specref_rail);
				glMateriali(GL_FRONT, GL_SHININESS, 64);
			}
			else
			{
				glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, Red);
				glMaterialfv(GL_FRONT, GL_SPECULAR, specref_rail);
				glMateriali(GL_FRONT, GL_SHININESS, 64);
			}
			glScalef(1, 0.2, 0.5);
			glutSolidCube(20);
		}
		glPopMatrix();
		glPushMatrix();
		{
			if (cant == -1)
			{
				glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, rail_steel);
				glMaterialfv(GL_FRONT, GL_SPECULAR, specref_rail);
				glMateriali(GL_FRONT, GL_SHININESS, 64);
			}
			else
			{
				glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, Red);
				glMaterialfv(GL_FRONT, GL_SPECULAR, specref_rail);
				glMateriali(GL_FRONT, GL_SHININESS, 64);
			}
			glTranslatef(-4, 0, 0);
			glScalef(0.2, 0.4, 1);
			glutSolidCube(20);
		}
		glPopMatrix();
		glPushMatrix();
		{
			if (cant == -1)
			{
				glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, rail_steel);
				glMaterialfv(GL_FRONT, GL_SPECULAR, specref_rail);
				glMateriali(GL_FRONT, GL_SHININESS, 64);
			}
			else
			{
				glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, Red);
				glMaterialfv(GL_FRONT, GL_SPECULAR, specref_rail);
				glMateriali(GL_FRONT, GL_SHININESS, 64);
			}
			glTranslatef(4, 0, 0);
			glScalef(0.2, 0.4, 1);
			glutSolidCube(20);
		}
		glPopMatrix();

		glEnable(GL_AUTO_NORMAL);
	}
	glPopMatrix();
}

void Draw_contol()
{
	for (int i = 0; i < current_amount; i++)
	{
		glPushMatrix();
		{
			glTranslatef(point[i][X], point[i][Y], point[i][Z]);
			glutSolidSphere(10, 5, 5);
		}
		glPopMatrix();
	}
}


//void Spline()
//{
//	for (int j = 0; j < current_amount; j++)
//	{
//		for (int i = 0; i < 10; i++)
//		{
//			if (current_amount < 1)
//			{
//				rail_road[0][0][X] = point[0][X];
//				rail_road[0][0][Y] = point[0][Y];
//				rail_road[0][0][Z] = point[0][Z];
//			}
//			else if (j < current_amount-1 && j != 0)
//			{
//				double t = i * 0.1;
//				rail_road[(j - 1)][i][X] = ((1 - t)*point[j - 1][X]) + (t * point[j - 1][X]);
//				rail_road[(j - 1)][i][Y] = ((1 - t)*point[j - 1][Y]) + (t * point[j - 1][Y]);
//				rail_road[(j - 1)][i][Z] = ((1 - t)*point[j - 1][Z]) + (t * point[j - 1][Z]);
//			}
//			if ([j - 2].exist == true && ctrlpoints[j - 1].exist == true && ctrlpoints[j].exist == true && j != 0 && j % 2 == 0)
//			{
//				double t = i * 0.05;
//				spot[(j - 2) * 10 + i].x = (2 * t*t - 3 * t + 1)*ctrlpoints[j - 2].x + (-4 * t*t + 4 * t)*ctrlpoints[j - 1].x + (2 * t*t - t)*ctrlpoints[j].x;
//				spot[(j - 2) * 10 + i].y = (2 * t*t - 3 * t + 1)*ctrlpoints[j - 2].y + (-4 * t*t + 4 * t)*ctrlpoints[j - 1].y + (2 * t*t - t)*ctrlpoints[j].y;
//				spot[(j - 2) * 10 + i].z = (2 * t*t - 3 * t + 1)*ctrlpoints[j - 2].z + (-4 * t*t + 4 * t)*ctrlpoints[j - 1].z + (2 * t*t - t)*ctrlpoints[j].z;
//				spot[(j - 2) * 10 + i].exist == true;
//
//				t = 0.5 + i * 0.05;
//				spot[(j - 1) * 10 + i].x = (2 * t*t - 3 * t + 1)*ctrlpoints[j - 2].x + (-4 * t*t + 4 * t)*ctrlpoints[j - 1].x + (2 * t*t - t)*ctrlpoints[j].x;
//				spot[(j - 1) * 10 + i].y = (2 * t*t - 3 * t + 1)*ctrlpoints[j - 2].y + (-4 * t*t + 4 * t)*ctrlpoints[j - 1].y + (2 * t*t - t)*ctrlpoints[j].y;
//				spot[(j - 1) * 10 + i].z = (2 * t*t - 3 * t + 1)*ctrlpoints[j - 2].z + (-4 * t*t + 4 * t)*ctrlpoints[j - 1].z + (2 * t*t - t)*ctrlpoints[j].z;
//				spot[(j - 1) * 10 + i].exist = true;
//			}
//
//			if (ctrlpoints[10].exist == true)
//			{
//				double t = 0.5 + i * 0.05;
//				spot[100 + i].x = (2 * t*t - 3 * t + 1)*ctrlpoints[9].x + (-4 * t*t + 4 * t)*ctrlpoints[10].x + (2 * t*t - t)*ctrlpoints[0].x;
//				spot[100 + i].y = (2 * t*t - 3 * t + 1)*ctrlpoints[9].y + (-4 * t*t + 4 * t)*ctrlpoints[10].y + (2 * t*t - t)*ctrlpoints[0].y;
//				spot[100 + i].z = (2 * t*t - 3 * t + 1)*ctrlpoints[9].z + (-4 * t*t + 4 * t)*ctrlpoints[10].z + (2 * t*t - t)*ctrlpoints[0].z;
//				spot[100 + i].exist = true;
//			}
//		}
//	}
//
//	for (int i = 0; i < 110; i++)
//	{
//		spot[i].xz_degree = get_degree(spot[i].x, spot[i].z, spot[i + 1].x, spot[i + 1].z);// *180 / 3.141592;
//		spot[i].xy_degree = get_degree(spot[i].x, spot[i].y, spot[i + 1].x, spot[i + 1].y);// *180 / 3.141592;
//		if (i == 109)
//		{
//			spot[i].xz_degree = get_degree(spot[i].x, spot[i].z, spot[0].x, spot[0].z);// *180 / 3.141592;
//			spot[i].xy_degree = get_degree(spot[i].x, spot[i].y, spot[0].x, spot[0].y);// *180 / 3.141592;
//		}
//	}
//}
int current_pos = 0;
int current_p = 0;
int current_pos1 = 0;
int current_p1 = 0;
int current_pos2 = 0;
int current_p2 = 0;
float pos_t = 0;
float rollerA[10][10][3] = { 0 };
float rollerB[10][10][3] = { 0 };
float rolletcoster_View[3] = { 0 };
float kx, ky, kz = 0;
void RollerCoster()
{

	float t = 0;
	int f = 0;


	for (int k = 0; k < current_amount; k += 1)
	{
		for (int j = 0; j < 25; j += 1)
		{
			if (t <= 1)
			{
				f = t * 10;
				t += 0.1;
			}
			else
			{
				t = 0;
			}
			for (int i = 0; i < 3; i++)
			{

				if (k == 0)
				{
					rollerA[k][f][i] = ((-t * t*t + 2 * t*t - t)*point[current_amount - 1][i] + (3 * t*t*t - 5 * t*t + 2)*point[0][i] + (-3 * t*t*t + 4 * t*t + t)*point[1][i] + (t*t*t - t * t)*point[2][i]) / 2;

				}
				if (k == current_amount - 1)
				{
					rollerA[k][f][i] = ((-t * t*t + 2 * t*t - t)*point[k - 1][i] + (3 * t*t*t - 5 * t*t + 2)*point[k][i] + (-3 * t*t*t + 4 * t*t + t)*point[0][i] + (t*t*t - t * t)*point[1][i]) / 2;
				}
				else if (k == current_amount - 2)
				{
					rollerA[k][f][i] = ((-t * t*t + 2 * t*t - t)*point[k - 1][i] + (3 * t*t*t - 5 * t*t + 2)*point[k][i] + (-3 * t*t*t + 4 * t*t + t)*point[k + 1][i] + (t*t*t - t * t)*point[0][i]) / 2;
				}
				else
				{
					rollerA[k][f][i] = ((-t * t*t + 2 * t*t - t)*point[k - 1][i] + (3 * t*t*t - 5 * t*t + 2)*point[k][i] + (-3 * t*t*t + 4 * t*t + t)*point[k + 1][i] + (t*t*t - t * t)*point[k + 2][i]) / 2;
				}
			}
		}
	}
	float railRadian[3];

	if (current_pos < current_amount && go == true)
	{
		pos_t += 0.1;
		if (pos_t >= 1.0f)
		{
			current_p += 1;
			pos_t = 0;
		}
		if (current_p < 8)
		{
			if (current_amount - 1 != current_pos)
			{
				//kx = (1.0f - pos_t)*rollerA[current_pos][current_p - 1][0] + pos_t * rollerA[current_pos][current_p][0];
				//ky = (1.0f - pos_t)*rollerA[current_pos][current_p - 1][1] + pos_t * rollerA[current_pos][current_p][1];
				//kz = (1.0f - pos_t)*rollerA[current_pos][current_p - 1][2] + pos_t * rollerA[current_pos][current_p][2];
			}
			if (current_p < 8)
			{
				
				if (current_p <= 7  && current_p > 1)
				{
					glPushMatrix();
					{
						glTranslatef((1.0f - pos_t)*rollerA[current_pos][current_p-1][0] + pos_t * rollerA[current_pos][current_p][0], (1.0f - pos_t)*rollerA[current_pos][current_p-1][1] + pos_t * rollerA[current_pos][current_p][1], (1.0f - pos_t)*rollerA[current_pos][current_p-1][2] + pos_t * rollerA[current_pos][current_p][2]);
						railRadian[XZ] = 180 / PI * atan2(rollerA[current_pos][current_p-1][X] - rollerA[current_pos][current_p][X], rollerA[current_pos][current_p-1][Z] - rollerA[current_pos][current_p][Z]);
						railRadian[XY] = 180 / PI * atan2(rollerA[current_pos][current_p-1][X] - rollerA[current_pos][current_p][X], rollerA[current_pos][current_p-1][Y] - rollerA[current_pos][current_p][Y]);
						glRotatef(railRadian[XZ], 0, 1.0f, 0);
						glRotatef(railRadian[XY], 0, 0, 1.0f);
						glutSolidCube(20);

					}
					glPopMatrix();
					glPushMatrix();
					{
						glTranslatef((1.0f - pos_t)*rollerA[current_pos][current_p - 2][0] + pos_t * rollerA[current_pos][current_p-1][0], (1.0f - pos_t)*rollerA[current_pos][current_p - 2][1] + pos_t * rollerA[current_pos][current_p-1][1], (1.0f - pos_t)*rollerA[current_pos][current_p - 2][2] + pos_t * rollerA[current_pos][current_p-1][2]);
						railRadian[XZ] = 180 / PI * atan2(rollerA[current_pos][current_p][X] - rollerA[current_pos][current_p + 1][X], rollerA[current_pos][current_p][Z] - rollerA[current_pos][current_p + 1][Z]);
						railRadian[XY] = 180 / PI * atan2(rollerA[current_pos][current_p][X] - rollerA[current_pos][current_p + 1][X], rollerA[current_pos][current_p][Y] - rollerA[current_pos][current_p + 1][Y]);
						glRotatef(railRadian[XZ], 0, 1.0f, 0);
						glRotatef(railRadian[XY], 0, 0, 1.0f);
						glutSolidCube(20);

					}
					glPopMatrix();
				}
				else if(current_p == 0 && current_pos > 0)
				{
					glPushMatrix();
					{
						glTranslatef((1.0f - pos_t)*rollerA[current_pos-1][7][0] + pos_t * rollerA[current_pos-1][8][0], (1.0f - pos_t)*rollerA[current_pos-1][7][1] + pos_t * rollerA[current_pos-1][8][1], (1.0f - pos_t)*rollerA[current_pos-1][7][2] + pos_t * rollerA[current_pos-1][8][2]);
						railRadian[XZ] = 180 / PI * atan2(rollerA[current_pos-1][7][X] - rollerA[current_pos-1][8][X], rollerA[current_pos-1][7][Z] - rollerA[current_pos-1][8][Z]);
						railRadian[XY] = 180 / PI * atan2(rollerA[current_pos-1][7][X] - rollerA[current_pos-1][8][X], rollerA[current_pos-1][7][Y] - rollerA[current_pos-1][8][Y]);
						glRotatef(railRadian[XZ], 0, 1.0f, 0);
						glRotatef(railRadian[XY], 0, 0, 1.0f);
						glutSolidCube(20);

					}
					glPopMatrix();
					glPushMatrix();
					{
						glTranslatef((1.0f - pos_t)*rollerA[current_pos-1][6][0] + pos_t * rollerA[current_pos-1][7][0], (1.0f - pos_t)*rollerA[current_pos-1][6][1] + pos_t * rollerA[current_pos-1][7][1], (1.0f - pos_t)*rollerA[current_pos-1][7][2] + pos_t * rollerA[current_pos-1][8][2]);
						railRadian[XZ] = 180 / PI * atan2(rollerA[current_pos-1][6][X] - rollerA[current_pos-1][7][X], rollerA[current_pos-1][6][Z] - rollerA[current_pos-1][7][Z]);
						railRadian[XY] = 180 / PI * atan2(rollerA[current_pos-1][6][X] - rollerA[current_pos-1][7][X], rollerA[current_pos-1][6][Y] - rollerA[current_pos-1][7][Y]);
						glRotatef(railRadian[XZ], 0, 1.0f, 0);
						glRotatef(railRadian[XY], 0, 0, 1.0f);
						glutSolidCube(20);

					}
					glPopMatrix();
				}
				else if (current_p == 1 && current_pos > 0)
				{
					glPushMatrix();
					{
						glTranslatef((1.0f - pos_t)*rollerA[current_pos][0][0] + pos_t * rollerA[current_pos][1][0], (1.0f - pos_t)*rollerA[current_pos][0][1] + pos_t * rollerA[current_pos][1][1], (1.0f - pos_t)*rollerA[current_pos][0][2] + pos_t * rollerA[current_pos][1][2]);
						railRadian[XZ] = 180 / PI * atan2(rollerA[current_pos][current_p - 1][X] - rollerA[current_pos][current_p][X], rollerA[current_pos][current_p - 1][Z] - rollerA[current_pos][current_p][Z]);
						railRadian[XY] = 180 / PI * atan2(rollerA[current_pos][current_p - 1][X] - rollerA[current_pos][current_p][X], rollerA[current_pos][current_p - 1][Y] - rollerA[current_pos][current_p][Y]);
						glRotatef(railRadian[XZ], 0, 1.0f, 0);
						glRotatef(railRadian[XY], 0, 0, 1.0f);
						glutSolidCube(20);

					}
					glPopMatrix();
					glPushMatrix();
					{
						glTranslatef((1.0f - pos_t)*rollerA[current_pos - 1][7][0] + pos_t * rollerA[current_pos - 1][8][0], (1.0f - pos_t)*rollerA[current_pos - 1][7][1] + pos_t * rollerA[current_pos - 1][8][1], (1.0f - pos_t)*rollerA[current_pos - 1][7][2] + pos_t * rollerA[current_pos - 1][8][2]);
						railRadian[XZ] = 180 / PI * atan2(rollerA[current_pos][current_p][X] - rollerA[current_pos][current_p + 1][X], rollerA[current_pos][current_p][Z] - rollerA[current_pos][current_p + 1][Z]);
						railRadian[XY] = 180 / PI * atan2(rollerA[current_pos][current_p][X] - rollerA[current_pos][current_p + 1][X], rollerA[current_pos][current_p][Y] - rollerA[current_pos][current_p + 1][Y]);
						glRotatef(railRadian[XZ], 0, 1.0f, 0);
						glRotatef(railRadian[XY], 0, 0, 1.0f);
						glutSolidCube(20);

					}
					glPopMatrix();
				}
				else if (current_p == 0 && current_pos == 0)
				{
					glPushMatrix();
					{
						glTranslatef((1.0f - pos_t)*rollerA[current_amount - 1][7][0] + pos_t * rollerA[current_amount - 1][8][0], (1.0f - pos_t)*rollerA[current_amount - 1][7][1] + pos_t * rollerA[current_amount - 1][8][1], (1.0f - pos_t)*rollerA[current_amount - 1][7][2] + pos_t * rollerA[current_amount - 1][8][2]);
						railRadian[XZ] = 180 / PI * atan2(rollerA[current_amount - 1][7][X] - rollerA[current_amount - 1][8][X], rollerA[current_amount - 1][7][Z] - rollerA[current_amount - 1][8][Z]);
						railRadian[XY] = 180 / PI * atan2(rollerA[current_amount - 1][7][X] - rollerA[current_amount - 1][8][X], rollerA[current_amount - 1][7][Y] - rollerA[current_amount - 1][8][Y]);
						glRotatef(railRadian[XZ], 0, 1.0f, 0);
						glRotatef(railRadian[XY], 0, 0, 1.0f);
						glutSolidCube(20);

					}
					glPopMatrix();
					glPushMatrix();
					{
						glTranslatef((1.0f - pos_t)*rollerA[current_amount - 1][6][0] + pos_t * rollerA[current_amount - 1][7][0], (1.0f - pos_t)*rollerA[current_amount - 1][6][1] + pos_t * rollerA[current_amount - 1][7][1], (1.0f - pos_t)*rollerA[current_amount - 1][6][2] + pos_t * rollerA[current_amount - 1][7][2]);
						railRadian[XZ] = 180 / PI * atan2(rollerA[current_amount - 1][6][X] - rollerA[current_amount - 1][7][X], rollerA[current_amount - 1][6][Z] - rollerA[current_amount - 1][7][Z]);
						railRadian[XY] = 180 / PI * atan2(rollerA[current_amount - 1][6][X] - rollerA[current_amount - 1][7][X], rollerA[current_amount - 1][6][Y] - rollerA[current_amount - 1][7][Y]);
						glRotatef(railRadian[XZ], 0, 1.0f, 0);
						glRotatef(railRadian[XY], 0, 0, 1.0f);
						glutSolidCube(20);

					}
					glPopMatrix();
				}
				else if (current_p == 1 && current_pos == 0)
				{
					glPushMatrix();
					{
						glTranslatef((1.0f - pos_t)*rollerA[current_pos][0][0] + pos_t * rollerA[current_pos][1][0], (1.0f - pos_t)*rollerA[current_pos][0][1] + pos_t * rollerA[current_pos][1][1], (1.0f - pos_t)*rollerA[current_pos][0][2] + pos_t * rollerA[current_pos][1][2]);
						railRadian[XZ] = 180 / PI * atan2(rollerA[current_pos][current_p - 1][X] - rollerA[current_pos][current_p][X], rollerA[current_pos][current_p - 1][Z] - rollerA[current_pos][current_p][Z]);
						railRadian[XY] = 180 / PI * atan2(rollerA[current_pos][current_p - 1][X] - rollerA[current_pos][current_p][X], rollerA[current_pos][current_p - 1][Y] - rollerA[current_pos][current_p][Y]);
						glRotatef(railRadian[XZ], 0, 1.0f, 0);
						glRotatef(railRadian[XY], 0, 0, 1.0f);
						glutSolidCube(20);

					}
					glPopMatrix();
					glPushMatrix();
					{
						glTranslatef((1.0f - pos_t)*rollerA[current_amount - 1][7][0] + pos_t * rollerA[current_amount - 1][8][0], (1.0f - pos_t)*rollerA[current_amount - 1][7][1] + pos_t * rollerA[current_amount - 1][8][1], (1.0f - pos_t)*rollerA[current_amount - 1][7][2] + pos_t * rollerA[current_amount - 1][8][2]);
						railRadian[XZ] = 180 / PI * atan2(rollerA[current_amount - 1][7][X] - rollerA[current_amount - 1][7 + 1][X], rollerA[current_amount - 1][7][Z] - rollerA[current_amount - 1][current_p + 1][Z]);
						railRadian[XY] = 180 / PI * atan2(rollerA[current_amount - 1][7][X] - rollerA[current_amount - 1][7 + 1][X], rollerA[current_amount - 1][7][Y] - rollerA[current_amount - 1][current_p + 1][Y]);
						glRotatef(railRadian[XZ], 0, 1.0f, 0);
						glRotatef(railRadian[XY], 0, 0, 1.0f);
						glutSolidCube(20);

					}
					glPopMatrix();
				}
				glPushMatrix();
				{
					glTranslatef((1.0f - pos_t)*rollerA[current_pos][current_p][0] + pos_t * rollerA[current_pos][current_p + 1][0], (1.0f - pos_t)*rollerA[current_pos][current_p][1] + pos_t * rollerA[current_pos][current_p + 1][1], (1.0f - pos_t)*rollerA[current_pos][current_p][2] + pos_t * rollerA[current_pos][current_p + 1][2]);
					railRadian[XZ] = 180 / PI * atan2(rollerA[current_pos][current_p][X] - rollerA[current_pos][current_p + 1][X], rollerA[current_pos][current_p][Z] - rollerA[current_pos][current_p + 1][Z]);
					railRadian[XY] = 180 / PI * atan2(rollerA[current_pos][current_p][X] - rollerA[current_pos][current_p + 1][X], rollerA[current_pos][current_p][Y] - rollerA[current_pos][current_p + 1][Y]);
					glRotatef(railRadian[XZ], 0, 1.0f, 0);
					glRotatef(railRadian[XY], 0, 0, 1.0f);
					glutSolidCube(20);

				}
				glPopMatrix();
				//glPushMatrix();
				//{
				//	kx = (1.0f - pos_t)*rollerA[current_pos][current_p][0] + pos_t * rollerA[current_pos][current_p + 1][0];
				//	ky = (1.0f - pos_t)*rollerA[current_pos][current_p][1] + pos_t * rollerA[current_pos][current_p + 1][1];
				//	kz = (1.0f - pos_t)*rollerA[current_pos][current_p][2] + pos_t * rollerA[current_pos][current_p + 1][2];
				//	glTranslatef(kx, ky + 50, kz);
				//	glutSolidSphere(50, 5, 5);
				//}
				//glPopMatrix();
				if (star == 4)
				{
					
					railRadian[XZ] = 180 / PI * atan2(rollerA[current_pos][current_p][X] - rollerA[current_pos][current_p + 1][X], rollerA[current_pos][current_p][Z] - rollerA[current_pos][current_p + 1][Z]);
					railRadian[XY] = 180 / PI * atan2(rollerA[current_pos][current_p][X] - rollerA[current_pos][current_p + 1][X], rollerA[current_pos][current_p][Y] - rollerA[current_pos][current_p + 1][Y]);
					//glRotatef(railRadian[XZ], 0, 1.0f, 0);
					//glRotatef(railRadian[XY], 0, 0, 1.0f);
					
					
						kx = (1.0f - pos_t)*rollerA[current_pos][current_p][0] + pos_t * rollerA[current_pos][current_p + 1][0];
						ky = (1.0f - pos_t)*rollerA[current_pos][current_p][1] + pos_t * rollerA[current_pos][current_p + 1][1];
						kz = (1.0f - pos_t)*rollerA[current_pos][current_p][2] + pos_t * rollerA[current_pos][current_p + 1][2];

						glMatrixMode(GL_MODELVIEW);
						glLoadIdentity();
						//gluLookAt(0, 0, 0, 0, 0, 0, up[0], up[1], up[2]);
						gluLookAt(kx, ky, kz, 0, 1,0,  0.0, 1.0, 0.0);
						//gluLookAt(eye[0], eye[1], eye[2], eye[0] + reye[0], eye[1] + reye[1], eye[2] + reye[2], 0.0, 1.0, 0.0);
						
					
				}	


			}
		}
		else
		{
			pos_t = 0;
			current_p = 0;
			current_pos += 1;
		}

	}
	else if (current_pos >= current_amount && go == true)
	{
		pos_t = 0;
		current_p = 0;
		current_pos = 0;
	}

}

void Spline()
{
	int f = 0;
	float t = 0;
	float railRadian[3];
	float cx, cy;
	int count_error = 0;

	for (int n = 0; n < 100; n++)
	{

		t += 0.04;
		if (t >= 1)
		{
			t = 0;
			f = (int)t * 25;
		}
		for (int k = 0; k < current_amount; k++)
		{
			//for (int i = 0; i < 3; i++)
			//{
			//   railCurruntPosition[k][i] = railPosition[k][i];
			//   if (t <= 0.5)
			//      railPosition[k][i] = (2 * t*t - 3 * t + 1)*ctrlpoints[k][i] + (-4 * t*t + 4 * t)*ctrlpoints[k+1][i] + (2 * t * t - t)*ctrlpoints[k+2][i];
			//}

			for (int i = 0; i < 3; i++)
			{
				rail_road[k][f][i] = rail_position[k][f][i];

				if (k == 0)
				{
					rail_position[k][f][i] = ((-t * t*t + 2 * t*t - t)*point[current_amount - 1][i] + (3 * t*t*t - 5 * t*t + 2)*point[0][i] + (-3 * t*t*t + 4 * t*t + t)*point[1][i] + (t*t*t - t * t)*point[2][i]) / 2;

				}
				if (k == current_amount - 1)
				{
					rail_position[k][f][i] = ((-t * t*t + 2 * t*t - t)*point[k - 1][i] + (3 * t*t*t - 5 * t*t + 2)*point[k][i] + (-3 * t*t*t + 4 * t*t + t)*point[0][i] + (t*t*t - t * t)*point[1][i]) / 2;
				}
				else if (k == current_amount - 2)
				{
					rail_position[k][f][i] = ((-t * t*t + 2 * t*t - t)*point[k - 1][i] + (3 * t*t*t - 5 * t*t + 2)*point[k][i] + (-3 * t*t*t + 4 * t*t + t)*point[k + 1][i] + (t*t*t - t * t)*point[0][i]) / 2;
				}
				else
				{
					rail_position[k][f][i] = ((-t * t*t + 2 * t*t - t)*point[k - 1][i] + (3 * t*t*t - 5 * t*t + 2)*point[k][i] + (-3 * t*t*t + 4 * t*t + t)*point[k + 1][i] + (t*t*t - t * t)*point[k + 2][i]) / 2;
				}
			}


			//if (railPosition[k][y] - railCurruntPosition[k][y] >= 0)
			//   railRadian[w] = atan2(railPosition[k][z] - railCurruntPosition[k][z], railPosition[k][y] - railCurruntPosition[k][y]);
			//else if (railPosition[k][y] - railCurruntPosition[k][y] < 0)
			//   railRadian[w] = atan2(railPosition[k][z] - railCurruntPosition[k][z], railCurruntPosition[k][y] - railPosition[k][y]);
			//railDegree[k][h] = 180 / PI * railRadian[h];

			railRadian[XZ] = 180 / PI * atan2(rail_road[k][f][X] - rail_position[k][f][X], rail_road[k][f][Z] - rail_position[k][f][Z]);
			railRadian[XY] = 180 / PI * atan2(rail_road[k][f][X] - rail_position[k][f][X], rail_road[k][f][Y] - rail_position[k][f][Y]);


			for (int i = 0; i < 10; i++)
			{
				cx = pow(Tree_locate[i][X] * 10 - 200 - rail_road[k][f][X], 2);
				cy = pow(Tree_locate[i][Y] * 10 - 200 - rail_road[k][f][Z], 2);
				if (cx + cy < 250)
				{
					cant = k;
					count_error += 1;
					break;
				}
				else
				{
					cant = -1;
				}
			}
			//railDegree[k][w] = 180 / PI * railRadian[w];
			if (t > 0.5f && t < 0.6f)
			{
				Rail_column(rail_road[k][f][X], rail_road[k][f][Y], rail_road[k][f][Z]);

			}
			glPushMatrix();
			{
				glTranslated(rail_road[k][f][X], rail_road[k][f][Y], rail_road[k][f][Z]);
				glRotatef(railRadian[XZ], 0, 1.0f, 0);
				glRotatef(railRadian[XY], 0, 0, 1.0f);
				//glRotated(railRadian[YZ], 1, 0, 0);
				//   glRotated(railDegree[k][h], 1, 0, 0);
				if (t > 0.4f && t < 0.6f)
				{
					tunnel();
				}
				Rail_model();
				
				position[k][f][X] = rail_position[k][f][X];
				position[k][f][Y] = rail_position[k][f][Y];
				position[k][f][Z] = rail_position[k][f][Z];

			}
		}
	}
	if (count_error > 0)
	{
		start_available = 0;
	}
	else
	{
		start_available = 1;
	}
	init = true;
}

void DrawTree()
{
	GLfloat leaf[] = { 0.3, 0.8, 0.0 };
	GLfloat root[] = { 0.8, 0.4, 0.0 };
	srand((unsigned int)time(NULL));
	static int tree_radious = 10;
	int x, z = 0;
	for (int i = 0; i < 10; i++)
	{
		while (Tree_locate[i][2] == 0)
		{
			x = rand() % 40;
			z = rand() % 40;
			for (int j = 0; j < i + 1; j++)
			{
				if (x == Tree_locate[j][0] && z == Tree_locate[j][1])
					Tree_locate[j][2] = 0;
				if (j == i)
				{
					Tree_locate[j][0] = x;
					Tree_locate[j][1] = z;
					Tree_locate[j][2] = 1;
				}
			}
		}
	}
	for (int i = 0; i < 10; i++)
	{
		if (Tree_locate[i][2] == 1)
		{
			glPushMatrix();
			{
				glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, leaf);
				glMaterialfv(GL_FRONT, GL_SPECULAR, specref);
				glMateriali(GL_FRONT, GL_SHININESS, 64);
				glTranslatef(Tree_locate[i][0] * 10 - MAKECENTER, -20, Tree_locate[i][1] * 10 - MAKECENTER);
				glutSolidSphere(tree_radious, 20, 20);
				glutWireSphere(tree_radious, 20, 20);
				glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, root);
				glMaterialfv(GL_FRONT, GL_SPECULAR, specref);
				glMateriali(GL_FRONT, GL_SHININESS, 64);
				glPushMatrix();
				{
					glTranslatef(0, -15, 0);
					glScalef(1.0f, 2.0f, 1.0f);
					glColor3f(0.7f, 0.3f, 0.0f);
					glutSolidCube(10);
				}
				glPopMatrix();
			}
			glPopMatrix();
		}
	}
}

void Moon()
{
	static int moon_angle = 0;
	glPushMatrix();
	{
		glRotatef(moon_angle, 0, 1, 0);
		glTranslatef(0, 20, 20);
		glutSolidSphere(20, 50, 50);
	}
	glPopMatrix();
	moon_angle = (moon_angle % 360) + 1;
}

void Draw_Ground() //�ٴ�
{
	for (int i = 0; i < 40; i++)
	{
		for (int j = 0; j < 40; j++)
		{
			glPushMatrix();
			{
				glTranslatef((i * 10) - 200, -50, (j * 10) - 200);
				glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, Cube_Color[i*j]);
				glMaterialfv(GL_FRONT, GL_SPECULAR, specref);
				glMateriali(GL_FRONT, GL_SHININESS, 64);
				glutSolidCube(10);
			}
			glPopMatrix();
		}
	}
}

void init_snow()
{
	int x, y, z = 0;
	srand((unsigned int)time(NULL));
	for (int i = 0; i < 40; i++)
	{
		for (int j = 0; j < 40; j++)
		{
			x = i * 10;
			y = (rand() % 400) + 200;
			z = j * 10;
			Snow_locate[i][j][0] = x;
			Snow_locate[i][j][1] = y;
			Snow_locate[i][j][2] = z;
		}
	}
}
void init_cube()
{
	for (int i = 0; i < 40; i++)
	{
		for (int j = 0; j < 40; j++)
		{

			Cube_Color[i*j][0] = 0;
			Cube_Color[i*j][1] = 0;
			Cube_Color[i*j][2] = 0;
		}
	}
}

void Fall_snow()
{
	for (int i = 0; i < 40; i++)
	{
		for (int j = 0; j < 40; j++)
		{
			if (Snow_locate[i][j][1] > -50)
			{
				Snow_locate[i][j][1] -= 0.2;
				glPushMatrix();
				{
					glTranslatef(Snow_locate[i][j][0] - 200, Snow_locate[i][j][1], Snow_locate[i][j][2] - 200);
					glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, gray);
					glMaterialfv(GL_FRONT, GL_SPECULAR, specref);
					glMateriali(GL_FRONT, GL_SHININESS, 128);
					glutSolidSphere(2, 8, 8);
				}
				glPopMatrix();
			}
			else
			{
				Snow_locate[i][j][1] = (rand() % 400) + 200;
				if (Cube_Color[i*j][0] < 1.0)
				{
					Cube_Color[i*j][0] += 0.05;
					Cube_Color[i*j][1] += 0.05;
					Cube_Color[i*j][2] += 0.05;
				}
			}
		}
	}
}

void Fall_rain()
{
	for (int i = 0; i < 40; i++)
	{
		for (int j = 0; j < 40; j++)
		{
			if (Snow_locate[i][j][1] > -50)
			{
				Snow_locate[i][j][1] -= 2;
				glPushMatrix();
				{
					glTranslatef(Snow_locate[i][j][0] - 200, Snow_locate[i][j][1], Snow_locate[i][j][2] - 200);
					glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, gray);
					glMaterialfv(GL_FRONT, GL_SPECULAR, specref);
					glMateriali(GL_FRONT, GL_SHININESS, 128);
					glScalef(0.2, 2, 0.2);
					glutSolidCube(5);
				}
				glPopMatrix();
			}
			else
			{
				Snow_locate[i][j][1] = (rand() % 400) + 200;
				if (Cube_Color[i*j][0] > 0.0)
				{
					Cube_Color[i*j][0] -= 0.05;
					Cube_Color[i*j][1] -= 0.05;
					Cube_Color[i*j][2] -= 0.05;
				}
			}
		}
	}
}
static bool fire = false;
static int b_dir = 0;
static int bullet_lo[3] = { 0 };
void Bullet()
{
	
	static int bx, by, bz = 0;
	
	
	
	if (fire == true)
	{

		if (b_dir == 0)
		{
			bullet_lo[0] += 2;
		}
		else if (b_dir == -1)
		{
			bullet_lo[0] -= 2;
		}
		else if (b_dir == 1)
		{
			bullet_lo[2] += 2;
		}
		else if (b_dir == 2)
		{
			bullet_lo[2] -= 2;
		}
		int cx, cz = 0;
		for (int i = 0; i < 10; i++)
		{
			cx = pow(bullet_lo[0] - Tree_locate[i][X] * 10 + MAKECENTER, 2);
			cz = pow(bullet_lo[2] - Tree_locate[i][Y] * 10 + MAKECENTER, 2);

			if (cx + cz < 3600)
			{
				fire = false;
			}

		}
		if (bullet_lo[0] > 200 || bullet_lo[0] < -200 || bullet_lo[2] > 200 || bullet_lo[2] < -200)
		{
			fire = false;
		}
		glPushMatrix();
		{
			glTranslatef(bullet_lo[0], bullet_lo[1], bullet_lo[2]);
			glutSolidSphere(50, 10, 10);
		}
		glPopMatrix();
	}
	
}
//������� �� �Լ���
int weather = 0;
void Keyboard(unsigned char key, int x, int y)
{
	switch (key) {
	case 'F':
		if (fire == false)
		{
			fire = true;
			if (robot_select == false)
			{
				b_dir = s_dir;
				bullet_lo[0] = s_location[0];
				bullet_lo[1] = s_location[1];
				bullet_lo[2] = s_location[2];
			}
			else if (robot_select == true)
			{
				b_dir = s_dir1;
				bullet_lo[0] = s_location1[0];
				bullet_lo[1] = s_location1[1];
				bullet_lo[2] = s_location1[2];
			}
		}
		break;
	case 'j':
		if (jump == false)
			jump = true;
		break;
	case 'J':
		if (robot_select == false)
		{
			robot_select = true;
		}
		else
		{
			robot_select = false;
		}
		break;
	case 'A':
		if (robot_select == false)
		{
			s_dir = -1;
		}
		else
		{
			s_dir1 = -1;
		}
		break;
	case 'D':
		if (robot_select == false)
		{
			s_dir = 0;
		}
		else
		{
			s_dir1 = 0;
		}
		break;
	case 'S':
		if (robot_select == false)
		{
			s_dir = 1;
		}
		else
		{
			s_dir1 = 1;
		}
		break;
	case 'W':
		if (robot_select == false)
		{
			s_dir = 2;
		}
		else
		{
			s_dir1 = 2;
		}
		break;
	case ',':
		weather += 1;
		weather = weather % 3;
		break;
	case '/':
		if (start_available == 1)
		{
			if (go == false)
			{
				go = true;
			}
			else if (go == true)
			{
				go = false;
			}
		}
		else
		{
			go = false;
		}

		break;
	case 'k':
		init_cube();
		break;
	case 'o':
		if (normal_switch == true)
			normal_switch = false;
		else if (normal_switch == false)
			normal_switch = true;
		break;
	case '1':
		if (one_light == true)
		{
			one_light = false;
		}
		else if (one_light == false)
			one_light = true;
		break;
	case '2':
		if (two_light == true)
		{
			two_light = false;
		}
		else if (two_light == false)
			two_light = true;
		break;
	case '3':
		DiffuseLight[0] -= 0.1;
		DiffuseLight[1] -= 0.1;
		DiffuseLight[2] -= 0.1;
		DiffuseLight1[0] -= 0.1;
		DiffuseLight1[1] -= 0.1;
		DiffuseLight1[2] -= 0.1;
		break;
	case '4':
		DiffuseLight[0] += 0.1;
		DiffuseLight[1] += 0.1;
		DiffuseLight[2] += 0.1;
		DiffuseLight1[0] += 0.1;
		DiffuseLight1[1] += 0.1;
		DiffuseLight1[2] += 0.1;
		break;
	case '5':
		if (specref[0] < 1)
		{
			specref[0] += 0.1;
			specref[1] += 0.1;
			specref[2] += 0.1;
		}
		break;
	case '6':
		if (specref[0] > 0)
		{
			specref[0] -= 0.1;
			specref[1] -= 0.1;
			specref[2] -= 0.1;
		}
		break;
	case '7':
		AmbientLight[0] -= 0.1;
		AmbientLight[1] -= 0.1;
		AmbientLight[2] -= 0.1;
		break;
	case '8':
		AmbientLight[0] += 0.1;
		AmbientLight[1] += 0.1;
		AmbientLight[2] += 0.1;
		break;
		break;
	case 't':
		if (light_angle_trigger != 1)
			light_angle_trigger = 1;
		else
			light_angle_trigger = 0;
		break;
	case 'T':
		if (light_angle_trigger != 2)
			light_angle_trigger = 2;
		else
			light_angle_trigger = 0;
		break;
	case 'y':
		light_angle = (light_angle % 360) + 5;
		break;
	case 'Y':
		light_angle = (light_angle % 360) - 5;
		break;
	case 'i':
		upp = 0;
		yard = 0;
		forward = 0;
		eye[0] = 0;
		eye[1] = 0;
		eye[2] = -1;
		anglee[0] = 0;
		anglee[1] = 0;
		anglee[2] = 0;
		break;
	case 'w':
		upp += 10;
		break;
	case 's':
		upp -= 10;
		break;
	case 'a':
		yard += 10;

		break;
	case 'd':
		yard -= 10;

		break;
	case '+':
		forward += 10;

		break;
	case '-':
		forward -= 10;
		break;
	case 'f':
		star += 1;
		star = star % 5;
		break;
	case 'b':
		anglee[0] = 0.0628f;
		orientMex(anglee[0]);
		if (anglee[0] >= 6.28)
		{
			anglee[0] = 0;
		}
		break;
	case 'B':
		anglee[0] = -0.0628f;
		orientMex(anglee[0]);
		if (anglee[0] >= 6.28)
		{
			anglee[0] = 0;
		}
		break;
	case 'n':
		anglee[1] = 0.0628f;
		orientMey(anglee[1]);
		if (anglee[1] >= 6.28)
		{
			anglee[1] = 0;
		}
		break;
	case 'N':
		anglee[1] = -0.0628f;
		orientMey(anglee[1]);
		if (anglee[1] >= 6.28)
		{
			anglee[1] = 0;
		}
		break;
	case 'm':
		anglee[2] = 0.0628f;
		orientMez(anglee[2]);
		if (anglee[2] <= -0.1)
		{
			anglee[2] = 0;
		}
		break;
	case 'M':
		anglee[2] = -0.0628f;
		orientMez(anglee[2]);
		if (anglee[2] >= 0.1)
		{
			anglee[2] = 0;
		}
		break;
	}
}

void DrawSphere()
{
	static int sight_angle = 0;
	blocked = 0;

	if (s_dir == 0)
	{
		sight_angle = 90;
	}
	else if (s_dir == -1)
	{
		sight_angle = -90;
	}
	else if (s_dir == 1)
	{
		sight_angle = 180;
	}
	else if (s_dir == 2)
	{
		sight_angle = 0;
	}

	int cx, cz = 0;
	if (s_location[0] >= 200 && s_dir == 0)
	{
		blocked = 1;
	}
	else if (s_location[0] <= -200 && s_dir == -1)
	{
		blocked = 1;
	}
	else if (s_location[2] <= -200 && s_dir == 2)
	{
		blocked = 1;
	}
	else if (s_location[2] >= 200 && s_dir == 1)
	{
		blocked = 1;
	}

	for (int i = 0; i < 10; i++)
	{
		cx = pow(s_location[0] - Tree_locate[i][X]*10+MAKECENTER, 2);
		cz = pow(s_location[2] - Tree_locate[i][Y]*10+MAKECENTER, 2);

		if (cx + cz < 3600)
		{
			if (s_dir == 0)
				blocked = 1;
			if (s_dir == 1)
				blocked = 1;
			if (s_location[1] <= 50)
			{
				jump = true;
			}
		}

	}
	cx = pow(s_location[0] - s_location1[0], 2);
	cz = pow(s_location[2] - s_location1[2], 2);
	if (cx + cz < 1000)
	{
		meet = true;
	}


	if (blocked == 0)
	{
		if (s_dir == 0)
		{
			s_location[0] += 2;
		}
		else if (s_dir == -1)
		{
			s_location[0] -= 2;
		}
		else if (s_dir == 1)
		{
			s_location[2] += 2;
		}
		else if (s_dir == 2)
		{
			s_location[2] -= 2;
		}
	}

	if (leg_updown == false)
	{
		leg_angle += 2;
		if (leg_angle > 30)
		{
			leg_updown = true;
		}
	}
	else if (leg_updown == true)
	{
		leg_angle -= 2;
		if (leg_angle < -30)
		{
			leg_updown = false;
		}
	}

	if (jump == true)
	{
		s_location[1] += 2;
		if (s_location[1] > 20)
			jump = false;
	}
	else if (jump == false && s_location[1] > 0)
	{
		s_location[1] -= 2;
	}

	glPushMatrix();
	{
		//glTranslatef(s_location[0], s_location[1], s_location[2]);
		glTranslatef(s_location[0], s_location[1], s_location[2]);
		glRotatef(sight_angle, 0.0, 1.0, 0.0);
		glColor3f(1.0f, 1.0f, 0.0f);
		glutSolidSphere(30, 20, 20);
		glLineWidth(3.0f);
		glColor3f(0.0f, 0.0f, 0.0f);
		glutWireSphere(30, 20, 20);
		glPushMatrix();
		{

			glRotatef(leg_angle, 1.0, 0.0, 0.0);
			glScalef(0.5, 1.0, 0.5);
			glTranslatef(15, -40, 0);
			glColor3f(1.0f, 0.0f, 0.0f);
			glutSolidCube(20);
			glLineWidth(3.0f);
			glColor3f(0.0f, 0.0f, 0.0f);
			glutWireCube(20);
		}
		glPopMatrix();

		glPushMatrix();
		{

			glRotatef(-leg_angle, 1.0, 0.0, 0.0);
			glScalef(0.5, 1.0, 0.5);
			glTranslatef(-15, -40, 0);
			glColor3f(1.0f, 0.0f, 0.0f);
			glutSolidCube(20);
			glLineWidth(3.0f);
			glColor3f(0.0f, 0.0f, 0.0f);
			glutWireCube(20);
		}
		glPopMatrix();

		glPushMatrix();
		{
			glTranslatef(25, 40, 0);
			glRotatef(-leg_angle, 1.0, 0.0, 0.0);
			glScalef(0.5, 1.5, 0.5);
			glTranslatef(0, -30, 0);
			glColor3f(1.0f, 0.0f, 0.0f);
			glutSolidCube(20);
			glLineWidth(3.0f);
			glColor3f(0.0f, 0.0f, 0.0f);
			glutWireCube(20);
		}
		glPopMatrix();

		glPushMatrix();
		{
			glTranslatef(-25, 40, 0);
			glRotatef(leg_angle, 1.0, 0.0, 0.0);
			glScalef(0.5, 1.5, 0.5);
			glTranslatef(0, -30, 0);
			glColor3f(1.0f, 0.0f, 0.0f);
			glutSolidCube(20);
			glLineWidth(3.0f);
			glColor3f(0.0f, 0.0f, 0.0f);
			glutWireCube(20);
		}
		glPopMatrix();
	}
	glPopMatrix();
}

void DrawSphere1()
{
	static int sight_angle1 = 0;
	blocked1 = 0;

	if (s_dir1 == 0)
	{
		sight_angle1 = 90;
	}
	else if (s_dir1 == -1)
	{
		sight_angle1 = -90;
	}
	else if (s_dir1 == 1)
	{
		sight_angle1 = 180;
	}
	else if (s_dir1 == 2)
	{
		sight_angle1 = 0;
	}

	int cx, cz = 0;
	if (s_location1[0] >= 200 && s_dir1 == 0)
	{
		blocked1 = 1;
	}
	else if (s_location1[0] <= -200 && s_dir1 == -1)
	{
		blocked1 = 1;
	}
	else if (s_location1[2] <= -200 && s_dir1 == 2)
	{
		blocked1 = 1;
	}
	else if (s_location1[2] >= 200 && s_dir1 == 1)
	{
		blocked1 = 1;
	}

	for (int i = 0; i < 10; i++)
	{
		cx = pow(s_location1[0] - Tree_locate[i][X] * 10 + MAKECENTER, 2);
		cz = pow(s_location1[2] - Tree_locate[i][Y] * 10 + MAKECENTER, 2);

		if (cx + cz < 1000)
		{
			if (s_dir1 == 0)
				blocked1 = 1;
			if (s_dir1 == 1)
				blocked1 = 1;
			if (s_location1[1] <= 20)
			{
				jump = true;
			}
		}

	}

	if (blocked1 == 0)
	{
		if (s_dir1 == 0)
		{
			s_location1[0] += 2;
		}
		else if (s_dir1 == -1)
		{
			s_location1[0] -= 2;
		}
		else if (s_dir1 == 1)
		{
			s_location1[2] += 2;
		}
		else if (s_dir1 == 2)
		{
			s_location1[2] -= 2;
		}
	}

	if (leg_updown == false)
	{
		leg_angle += 2;
		if (leg_angle > 30)
		{
			leg_updown = true;
		}
	}
	else if (leg_updown == true)
	{
		leg_angle -= 2;
		if (leg_angle < -30)
		{
			leg_updown = false;
		}
	}

	if (jump1 == true)
	{
		s_location1[1] += 2;
		if (s_location1[1] > 20)
			jump1 = false;
	}
	else if (jump1 == false && s_location1[1] > 0)
	{
		s_location1[1] -= 2;
	}

	glPushMatrix();
	{
		//glTranslatef(s_location[0], s_location[1], s_location[2]);
		glTranslatef(s_location1[0], s_location1[1], s_location1[2]);
		glRotatef(sight_angle1, 0.0, 1.0, 0.0);
		glColor3f(1.0f, 1.0f, 0.0f);
		glutSolidSphere(30, 20, 20);
		glLineWidth(3.0f);
		glColor3f(0.0f, 0.0f, 0.0f);
		glutWireSphere(30, 20, 20);
		glPushMatrix();
		{

			glRotatef(leg_angle, 1.0, 0.0, 0.0);
			glScalef(0.5, 1.0, 0.5);
			glTranslatef(15, -40, 0);
			glColor3f(1.0f, 0.0f, 0.0f);
			glutSolidCube(20);
			glLineWidth(3.0f);
			glColor3f(0.0f, 0.0f, 0.0f);
			glutWireCube(20);
		}
		glPopMatrix();

		glPushMatrix();
		{

			glRotatef(-leg_angle, 1.0, 0.0, 0.0);
			glScalef(0.5, 1.0, 0.5);
			glTranslatef(-15, -40, 0);
			glColor3f(1.0f, 0.0f, 0.0f);
			glutSolidCube(20);
			glLineWidth(3.0f);
			glColor3f(0.0f, 0.0f, 0.0f);
			glutWireCube(20);
		}
		glPopMatrix();

		glPushMatrix();
		{
			glTranslatef(25, 40, 0);
			glRotatef(-leg_angle, 1.0, 0.0, 0.0);
			glScalef(0.5, 1.5, 0.5);
			glTranslatef(0, -30, 0);
			glColor3f(1.0f, 0.0f, 0.0f);
			glutSolidCube(20);
			glLineWidth(3.0f);
			glColor3f(0.0f, 0.0f, 0.0f);
			glutWireCube(20);
		}
		glPopMatrix();

		glPushMatrix();
		{
			glTranslatef(-25, 40, 0);
			glRotatef(leg_angle, 1.0, 0.0, 0.0);
			glScalef(0.5, 1.5, 0.5);
			glTranslatef(0, -30, 0);
			glColor3f(1.0f, 0.0f, 0.0f);
			glutSolidCube(20);
			glLineWidth(3.0f);
			glColor3f(0.0f, 0.0f, 0.0f);
			glutWireCube(20);
		}
		glPopMatrix();
	}
	glPopMatrix();
}

int select_num = -1;
int warning = -1;

void Mouse(int button, int state, int x, int y)
{
	if (button == GLUT_LEFT_BUTTON && state == GLUT_DOWN)
	{
		mx = x;
		my = y;

		left_button = TRUE;
		init = false;
		if (go == false)
		{
			if (current_amount != 10 and star == 3)
			{
				float cx;
				float cy;
				for (int i = 0; i < 10; i++)
				{
					cx = pow(Tree_locate[i][X] * 10 - 200 - x + 400, 2);
					cy = pow(Tree_locate[i][Y] * 10 - 200 - y + 300, 2);
					if (cx + cy < 250)
					{
						warning = 1;
					}
				}
				if (warning != 1)
				{
					point[current_amount][X] = x - 400;
					point[current_amount][Y] = 10;
					point[current_amount][Z] = y - 300;
					current_amount += 1;
				}
				warning = 0;
			}
		}
	}
	else
	{
		left_button = FALSE;
	}

	if (button == GLUT_RIGHT_BUTTON && state == GLUT_DOWN)
	{
		mx = x;
		my = y;
		float cx;
		float cy;

		right_button = TRUE;

		if (go == false)
		{
			if (star == 3)
			{
				for (int i = 0; i < current_amount; i++)
				{
					cx = pow(point[i][X] - x + 400, 2);
					cy = pow(point[i][Z] - y + 300, 2);
					if (cx + cy < 1000)
					{
						select_num = i;
						break;
					}
				}
			}
			if (star == 2)
			{
				for (int i = 0; i < current_amount; i++)
				{
					cx = pow(point[i][X] - x + 400, 2);
					cy = pow(point[i][Y] + y - 300, 2);
					if (cx + cy < 1000)
					{
						select_num = i;
						break;
					}
				}
			}
		}

	}
	else
	{
		right_button = FALSE;

		select_num = -1;
	}
}
void Motion(int x, int y)
{
	if (left_button == true)
	{
		mx = x;
		my = y;
		mdown = TRUE;
	}
	else
	{
		mdown = FALSE;
	}

	if (right_button == true)
	{
		mx = x;
		my = y;

		mdown = TRUE;

		if (star == 3)
		{
			if (select_num > -1)
			{
				float cx;
				float cy;
				for (int i = 0; i < 10; i++)
				{
					cx = pow(Tree_locate[i][X] * 10 - 200 - x + 400, 2);
					cy = pow(Tree_locate[i][Y] * 10 - 200 - y + 300, 2);
					if (cx + cy < 250)
					{
						warning = 1;
					}
				}
				if (warning != 1)
				{
					point[select_num][X] = x - 400;
					point[select_num][Z] = y - 300;
				}
				warning = 0;
			}
		}

		if (star == 2)
		{
			if (select_num > -1)
			{
				point[select_num][X] = x - 400;
				point[select_num][Y] = -y + 300;
			}
		}
	}
	else
	{
		mdown = FALSE;
	}



}

void main(int argc, char *argv[])
{
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGBA | GLUT_DEPTH);
	glutInitWindowPosition(100, 100);
	glutInitWindowSize(800, 600);
	glutCreateWindow("�ǽ�");
	glutDisplayFunc(drawScene);
	glutKeyboardFunc(Keyboard);
	init_snow();
	s_location1[1] = 0;
	glutMouseFunc(Mouse);
	glutMotionFunc(Motion);
	glutTimerFunc(timer, TimerFunction, 1);
	glutReshapeFunc(Reshape);
	glutMainLoop();
}

GLvoid drawScene(GLvoid)
{
	glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	//glLineWidth(5.0f);
	//glBegin(GL_LINES);
	//glColor3f(1.0f, 0.0f, 0.0f);			// XYZ�� �׸��� ��
	//glVertex3f(-400.0f, 0, 0);
	//glVertex3f(400.0f, 0, 0);
	//glColor3f(0.0f, 1.0f, 0.0f);
	//glVertex3f(0.0f, -300.0f, 0);
	//glVertex3f(0.0f, 300.0f, 0);
	//glColor3f(0.0f, 0.0f, 1.0f);
	//glVertex3f(0.0f, 0, -300.0f);
	//glVertex3f(0.0f, 0, 300.0f);
	//glEnd();
	//glPopMatrix();
	glPushMatrix();
	{
		glRotated(light_angle, 0, 1, 0);
		Lighting();
	}
	glPopMatrix();
	Moon();
	Draw_Ground();
	DrawTree();
	Spline();
	Draw_contol();
	RollerCoster();
	Bullet();
	DrawSphere1();
		DrawSphere();
		if (meet == true && robot_select == false)
		{
			s_location1[0] = s_location[0];
			s_location1[1] = s_location[1];
			s_location1[2] = s_location[2]-100;
			s_dir1 = s_dir;
		}
		else if (meet == true && robot_select == true)
		{
			s_location[0] = s_location1[0];
			s_location[1] = s_location1[1];
			s_location[2] = s_location1[2]+100;
			s_dir = s_dir1;
		}
	if (weather == 0)
	{
		Fall_snow();
	}
	else if (weather == 1)
	{
		Fall_rain();
	}
	else if (weather == 2)
	{
	}
	glEnable(GL_DEPTH_TEST);
	if (star == 0)
	{
		glMatrixMode(GL_PROJECTION);
		glLoadIdentity();
		gluPerspective(60.0f, 800 / 600, 1.0, 600.0);
		glTranslatef(0.0, 0.0, -300.0);

	}
	else if (star == 1)
	{
		glMatrixMode(GL_MODELVIEW);
		glLoadIdentity();
		//gluLookAt(0, 0, 0, 0, 0, 0, up[0], up[1], up[2]);
		gluLookAt(0, 0, 0, eye[0], eye[1], eye[2], 0.0, 1.0, 0.0);
		//gluLookAt(eye[0], eye[1], eye[2], eye[0] + reye[0], eye[1] + reye[1], eye[2] + reye[2], 0.0, 1.0, 0.0);
	}
	else if (star == 2)
	{
		glViewport(0, 0, 800, 600);
		glMatrixMode(GL_PROJECTION);
		glLoadIdentity();
		glOrtho(-500.0f, 500.0f, -400.0f, 400.0f, -400.0f, 400.0f);
		glMatrixMode(GL_MODELVIEW);
		glLoadIdentity();
	}
	else if (star == 3)
	{
		glViewport(0, 0, 800, 600);
		glMatrixMode(GL_PROJECTION);
		glLoadIdentity();
		glOrtho(-400.0f, 400.0f, -300.0f, 300.0f, -300.0f, 300.0f);
		glMatrixMode(GL_MODELVIEW);
		glLoadIdentity();
		glRotatef(90, 1, 0, 0);
	}
	
	glTranslatef(yard, upp, forward);
	glutSwapBuffers();
}

GLvoid Reshape(int w, int h)
{
	glViewport(0, 0, w, h);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(60.0f, w / h, 1.0, 1200.0);
	glTranslatef(0.0, 0.0, -300.0);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
}

void TimerFunction(int value)
{
	glutPostRedisplay();
	glutTimerFunc(timer, TimerFunction, 1);
}
